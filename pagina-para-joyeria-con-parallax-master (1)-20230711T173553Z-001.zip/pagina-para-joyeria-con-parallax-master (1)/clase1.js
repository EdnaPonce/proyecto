/*var nombre=prompt("como te llamas");
var edad=parseInt(prompt("como te llamas")) ;
var empleado =prompt("empleado");
var salario= prompt("dime tu salario ");

var nombre=("como te llamas");
var edad=10;
var empleado =true;
var salario= ("dime tu salario ");


console.log(typeof nombre);
console.log(typeof edad);
console.log(typeof empleado);
console.log(typeof salario);




console.log(nombre);
console.log(typeof nombre);

console.log(edad);
console.log(typeof edad);

console.log(empleado);
console.log(typeof empleado);

console.log(salario);
console.log(typeof salario);



/*pedir dos numeros y la suma*/
 /*
var num1=parseInt(prompt("primer numero ")) ;
var num2=parseInt(prompt("segundo nuemero")) ;

var suma =num1+num2;

console.log(suma);


alert(suma);
*/
'use stric'
var alumno ="daniel";
var alumnos =["daniel","edna","german"];
var materias=new Array("computacion paralela ");
var registros =[123456,231456,12254];


console.log(alumnos.length);
console.log("alumno", alumnos[2],"inscrito en la materia:", materias[0]);
console.log("alumno", alumnos[2],"inscrito en la materia:", registro[1]);

for(var i=0;i<alumnos.length;i++){
    console.log(mate);
}

for (var i=0;i<alumnos.length;i++){
console.log
}

for(var ){
    console.log(mate);
}



var nombre=prompt("ingrese nombre")
var confir =condirm("desea inscribirte ?");
console.log(confir);

if(confir==true)
{
    console.log("gracias por inscribirte", nombre);
}else{
    console.log("gracias por contactarnos", nombre);
}